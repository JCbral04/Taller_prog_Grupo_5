package modelo;

import java.io.Serializable;

public class Persona implements Serializable {
    private String nombre; //Cada caracter ocupa 2 bytes
    private int edad; //ocupa 4 bytes
    //private boolean activo;
    
    public Persona(){
        nombre = "NN";
        edad = 0;
        //activo = true;
    }
    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    public void setNombre(String nombre){ this.nombre = nombre;}
    
    public String getNombre(){
        return nombre;
    }
    public void getEdad(int edad){
        this.edad = edad;
    }
    public int getEdad(){
        return edad;
    }
    @Override
    public String toString(){
        return "\nNombre: " + nombre +
               "\nEdad: " + edad;
    }
    public int getTamaño(){
        return getNombre().length()*2 + 2 + 4;
    }
}
