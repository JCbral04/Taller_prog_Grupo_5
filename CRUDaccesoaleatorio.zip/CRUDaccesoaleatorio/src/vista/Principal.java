package vista;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import controlador.AccesoAleatorio;
import modelo.Persona;

public class Principal extends JPanel {
    private JTextField txtNombre, txtEdad, txtBuscar, txtEliminar;
    private JButton btnAgregar, btnBuscar, btnEliminar;
    private AccesoAleatorio acceso; // Objeto para manejar el archivo

    public Principal() {
        try {
            acceso = new AccesoAleatorio("personas.dat"); // Inicializar el acceso al archivo
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al abrir el archivo", "Error", JOptionPane.ERROR_MESSAGE);
        }

        setLayout(new GridLayout(3, 1));

        // Panel de Registro
        JPanel panelRegistro = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelRegistro.setBorder(BorderFactory.createTitledBorder("Registrar nueva persona"));
        JLabel lblNombre = new JLabel("Ingrese nombre:");
        lblNombre.setPreferredSize(new Dimension(150, 25));
        txtNombre = new JTextField(15);
        JLabel lblEdad = new JLabel("Ingrese edad:");
        lblEdad.setPreferredSize(new Dimension(150, 25));
        txtEdad = new JTextField(5);
        btnAgregar = new JButton("Agregar persona");

        panelRegistro.add(lblNombre);
        panelRegistro.add(txtNombre);
        panelRegistro.add(lblEdad);
        panelRegistro.add(txtEdad);
        panelRegistro.add(btnAgregar);
        add(panelRegistro);

        // Panel de Búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelBusqueda.setBorder(BorderFactory.createTitledBorder("Buscar persona registrada"));
        JLabel lblBuscar = new JLabel("Nombre a buscar:");
        lblBuscar.setPreferredSize(new Dimension(180, 25));
        txtBuscar = new JTextField(15);
        btnBuscar = new JButton("Buscar persona");

        panelBusqueda.add(lblBuscar);
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        add(panelBusqueda);

        // Panel de Eliminación
        JPanel panelEliminar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelEliminar.setBorder(BorderFactory.createTitledBorder("Eliminar persona registrada"));
        JLabel lblEliminar = new JLabel("Nombre de la persona a eliminar:");
        lblEliminar.setPreferredSize(new Dimension(180, 25));
        txtEliminar = new JTextField(15);
        btnEliminar = new JButton("Eliminar persona");

        panelEliminar.add(lblEliminar);
        panelEliminar.add(txtEliminar);
        panelEliminar.add(btnEliminar);
        add(panelEliminar);

        // ➤ Agregar eventos a los botones
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarPersona();
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarPersona();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarPersona();
            }
        });
    }

    // ➤ Método para agregar persona
    private void agregarPersona() {
        try {
            String nombre = txtNombre.getText().trim();
            int edad = Integer.parseInt(txtEdad.getText().trim());
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            acceso.agregarPersona(new Persona(nombre, edad));
            JOptionPane.showMessageDialog(this, "Persona agregada correctamente.");
            txtNombre.setText("");
            txtEdad.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese una edad válida.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al escribir en el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ➤ Método para buscar persona
    private void buscarPersona() {
        try {
            String nombre = txtBuscar.getText().trim();
            Persona persona = acceso.buscarPersona(nombre);
            if (persona != null) {
                JOptionPane.showMessageDialog(this, "Persona encontrada:\n" + persona.toString());
            } else {
                JOptionPane.showMessageDialog(this, "Persona no encontrada.");
            }
            txtBuscar.setText("");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ➤ Método para eliminar persona
    private void eliminarPersona() {
        try {
            String nombre = txtEliminar.getText().trim();
            boolean eliminado = acceso.eliminarPersona(nombre);
            if (eliminado) {
                JOptionPane.showMessageDialog(this, "Persona eliminada correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "Persona no encontrada.");
            }
            txtEliminar.setText("");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error al modificar el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ➤ Cerrar archivo al cerrar la aplicación
    public void cerrarArchivo() {
        try {
            acceso.cerrarArchivo();
        } catch (IOException e) {
            System.err.println("Error al cerrar el archivo.");
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestión de Personas");
        Principal panel = new Principal();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 350);
        frame.setContentPane(panel);
        frame.setLocationRelativeTo(null); // Centrar la ventana
        frame.setVisible(true);

        // Cerrar archivo al cerrar la ventana
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                panel.cerrarArchivo();
            }
        });
    }
}
