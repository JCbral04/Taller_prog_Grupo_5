package controlador;

import modelo.Persona;
import java.io.*;

public class AccesoAleatorio {
    private RandomAccessFile archivo;

    public AccesoAleatorio(String nombreArchivo) throws IOException {
        archivo = new RandomAccessFile(nombreArchivo, "rw");
    }

    public void cerrarArchivo() throws IOException {
        if (archivo != null) {
            archivo.close();
        }
    }

    public void agregarPersona(Persona persona) throws IOException {
        archivo.seek(archivo.length()); // Ir al final del archivo
        archivo.writeUTF(persona.getNombre());
        archivo.writeInt(persona.getEdad());
    }

    public Persona buscarPersona(String nombre) throws IOException {
        archivo.seek(0); // Volver al inicio
        while (archivo.getFilePointer() < archivo.length()) {
            String nombreLeido = archivo.readUTF();
            int edadLeida = archivo.readInt();
            if (nombreLeido.equalsIgnoreCase(nombre)) {
                return new Persona(nombreLeido, edadLeida);
            }
        }
        return null; // No encontrada
    }

    public boolean actualizarPersona(String nombre, int nuevaEdad) throws IOException {
        archivo.seek(0);
        while (archivo.getFilePointer() < archivo.length()) {
            long posicion = archivo.getFilePointer();
            String nombreLeido = archivo.readUTF();
            int edadLeida = archivo.readInt();
            if (nombreLeido.equalsIgnoreCase(nombre)) {
                archivo.seek(posicion + nombreLeido.length() + 2); // Saltar nombre
                archivo.writeInt(nuevaEdad);
                return true;
            }
        }
        return false;
    }

    public boolean eliminarPersona(String nombre) throws IOException {
        File tempFile = new File("temp.dat");
        RandomAccessFile tempArchivo = new RandomAccessFile(tempFile, "rw");

        archivo.seek(0);
        boolean eliminado = false;
        
        while (archivo.getFilePointer() < archivo.length()) {
            String nombreLeido = archivo.readUTF();
            int edadLeida = archivo.readInt();

            if (!nombreLeido.equalsIgnoreCase(nombre)) {
                tempArchivo.writeUTF(nombreLeido);
                tempArchivo.writeInt(edadLeida);
            } else {
                eliminado = true;
            }
        }

        archivo.close();
        tempArchivo.close();

        File archivoOriginal = new File("personas.dat");
        archivoOriginal.delete();
        tempFile.renameTo(archivoOriginal);
        archivo = new RandomAccessFile("personas.dat", "rw");
        
        return eliminado;
    }
}
