import javax.swing.JOptionPane;

public class Excepciones {
    
    public static int division;
    
    public static void main(String[] args) {
        int numerador = 12;
        int denominador = 0;
        String cadena = "UNDOSTRES123";
        
        try {
            division = numerador / denominador;
        } catch (ArithmeticException e) {
            JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
            division = 0;
        } finally {
            JOptionPane.showMessageDialog(null, "LA OPERACIÓN QUEDÓ EN: " + division, "INFORMACIÓN", JOptionPane.INFORMATION_MESSAGE);
        }

        if (isNumeric(cadena)) {
            System.out.println("ES UN NÚMERO");
        } else {
            System.out.println("NO ES UN NÚMERO");
        }
    }

    // Método auxiliar para verificar si una cadena es numérica
    public static boolean isNumeric(String str) {
        return str.matches("\\d+");
    }
}

