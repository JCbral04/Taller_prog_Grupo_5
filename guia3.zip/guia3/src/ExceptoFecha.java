
public class ExceptoFecha extends Exception {
    public ExceptoFecha (String s){
        super(s);
    }
}
