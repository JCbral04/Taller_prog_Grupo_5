
public class Fecha {

    int grupo = 0;

    void comprobar(int dd, int mm, int aa) throws ExceptoFecha {
        switch (mm) {
            case 1: case 3: case 5: case 7: case 8: case 10: case 12:
                grupo = 1; // Meses de 31 días
                break;
            case 4: case 6: case 9: case 11:
                grupo = 2; // Meses de 30 días
                break;
            case 2:
                grupo = 3; // Febrero
                break;
            default:
                throw new ExceptoFecha("Fecha Incorrecta. Mes No Legítimo");
        }

        switch (grupo) {
            case 1:
                if (dd < 1 || dd > 31) {
                    throw new ExceptoFecha("Fecha Incorrecta. Día del Mes");
                }
                break;
            case 2:
                if (dd < 1 || dd > 30) {
                    throw new ExceptoFecha("Fecha Incorrecta. Día del Mes");
                }
                break;
            case 3:
                if ((aa % 4 == 0 && aa % 100 != 0) || (aa % 400 == 0)) {
                    if (dd < 1 || dd > 29) {
                        throw new ExceptoFecha("Fecha Incorrecta. Día del Mes (Año Bisiesto)");
                    }
                } else {
                    if (dd < 1 || dd > 28) {
                        throw new ExceptoFecha("Fecha Incorrecta. Día del Mes (No Bisiesto)");
                    }
                }
                break;
        }
    }
}

