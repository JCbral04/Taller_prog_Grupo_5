import javax.swing.JOptionPane;

public class Fechas {
    public static void main(String[] args) {
        int dd = 0, mm = 0, aa = 0;
        Fecha F = new Fecha();

        do {
            try {
                dd = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite Día: "));
                mm = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite Mes: "));

                do {
                    aa = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite Año desde 1963: "));
                } while (aa < 1963);

                F.comprobar(dd, mm, aa);
                
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "ERROR: Debe ingresar un número válido.", "ERROR", JOptionPane.ERROR_MESSAGE);
                dd = mm = aa = 0;
            } catch (ExceptoFecha e) {
                JOptionPane.showMessageDialog(null, e.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
                dd = mm = aa = 0;
            }
        } while (dd == 0 || mm == 0 || aa == 0);

        JOptionPane.showMessageDialog(null, "Fecha ingresada correctamente: " + dd + "/" + mm + "/" + aa);
        System.exit(0);
    }
}

