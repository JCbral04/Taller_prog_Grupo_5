import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MatrixMultiplier {
    private final int[][] matrixA;
    private final int[][] matrixB;
    private final int[][] result;
    private final int numThreads;

    public MatrixMultiplier(int[][] matrixA, int[][] matrixB, int numThreads) {
        this.matrixA = matrixA;
        this.matrixB = matrixB;
        this.result = new int[matrixA.length][matrixB[0].length];
        this.numThreads = numThreads;
    }

    public int[][] multiply() {
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        int rowsPerThread = matrixA.length / numThreads;
        int extraRows = matrixA.length % numThreads;
        int currentRow = 0;

        for (int i = 0; i < numThreads; i++) {
            int rows = (i < extraRows) ? rowsPerThread + 1 : rowsPerThread;
            executor.execute(new Worker(currentRow, currentRow + rows));
            currentRow += rows;
        }

        executor.shutdown();
        while (!executor.isTerminated()) {}
        return result;
    }
    
private class Worker implements Runnable {
    private final int startRow;
    private final int endRow;
    
    public Worker (int startRow, int endRow){
        this.startRow = startRow;
        this.endRow = endRow;
    }
    @Override
    public void run() {
        for (int i= startRow; i < endRow; i++){
            for (int j = 0; j < matrixB[0].length; j++){
                for (int k = 0; k < matrixA[0].length; k++){
                    result[i][j] += matrixA[i][k] * matrixB[k][j];
                }
            }
        }
    }
}
}