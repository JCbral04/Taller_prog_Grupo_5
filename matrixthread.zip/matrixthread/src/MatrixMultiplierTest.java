import java.util.Random;

public class MatrixMultiplierTest {
    public static void main(String[] args) {
        int size = 500; // Tamaño de la matriz NxN
        int numThreads = 4;

        int[][] matrixA = generateRandomMatrix(size, size);
        int[][] matrixB = generateRandomMatrix(size, size);

        // Multiplicación paralela
        MatrixMultiplier parallelMultiplier = new MatrixMultiplier(matrixA, matrixB, numThreads);
        long startParallel = System.nanoTime();
        int[][] resultParallel = parallelMultiplier.multiply();
        long endParallel = System.nanoTime();
        long timeParallel = (endParallel - startParallel) / 1_000_000; // en milisegundos

        // Multiplicación secuencial
        long startSequential = System.nanoTime();
        int[][] resultSequential = sequentialMultiply(matrixA, matrixB);
        long endSequential = System.nanoTime();
        long timeSequential = (endSequential - startSequential) / 1_000_000; // en milisegundos

        System.out.println("Tiempo (paralelo): " + timeParallel + " ms");
        System.out.println("Tiempo (secuencial): " + timeSequential + " ms");

        // Opcional: verificar que ambos resultados son iguales
        System.out.println("¿Resultados iguales? " + matricesIguales(resultParallel, resultSequential));
    }

    public static int[][] generateRandomMatrix(int rows, int cols) {
        Random rand = new Random();
        int[][] matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                matrix[i][j] = rand.nextInt(10); // valores entre 0 y 9
        return matrix;
    }

    public static int[][] sequentialMultiply(int[][] A, int[][] B) {
        int[][] result = new int[A.length][B[0].length];
        for (int i = 0; i < A.length; i++) {
            for (int j = 0; j < B[0].length; j++) {
                for (int k = 0; k < A[0].length; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return result;
    }
    

    public static boolean matricesIguales(int[][] A, int[][] B) {
        if (A.length != B.length || A[0].length != B[0].length)
            return false;
        for (int i = 0; i < A.length; i++)
            for (int j = 0; j < A[0].length; j++)
                if (A[i][j] != B[i][j])
                    return false;
        return true;
    }
}
