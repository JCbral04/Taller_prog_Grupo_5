package vista;

import dao.UsuarioDAO;
import modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class UsuarioGUI extends JFrame {
    private JTextField txtTipoID, txtNroID, txtNombres, txtCorreo, txtCelular;
    private JButton btnAgregar, btnActualizar, btnEliminar, btnListar;
    private JTextArea txtAreaUsuarios;
    private UsuarioDAO usuarioDAO;

    public UsuarioGUI() {
        usuarioDAO = new UsuarioDAO();

        // Configuración de la ventana
        setTitle("Gestión de Usuarios");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centra la ventana en la pantalla
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Espaciado entre elementos
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Fila 1: Tipo ID y Número ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(new JLabel("Tipo ID:"), gbc);

        gbc.gridx = 1;
        txtTipoID = new JTextField(10);
        add(txtTipoID, gbc);

        gbc.gridx = 2;
        add(new JLabel("Número ID:"), gbc);

        gbc.gridx = 3;
        txtNroID = new JTextField(10);
        add(txtNroID, gbc);

        // Fila 2: Nombres
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Nombres:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        txtNombres = new JTextField(20);
        add(txtNombres, gbc);
        gbc.gridwidth = 1;

        // Fila 3: Correo y Celular
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Correo:"), gbc);

        gbc.gridx = 1;
        txtCorreo = new JTextField(10);
        add(txtCorreo, gbc);

        gbc.gridx = 2;
        add(new JLabel("Celular:"), gbc);

        gbc.gridx = 3;
        txtCelular = new JTextField(10);
        add(txtCelular, gbc);

        // Fila 4: Botones
        gbc.gridx = 0;
        gbc.gridy = 3;
        btnAgregar = new JButton("Agregar");
        add(btnAgregar, gbc);

        gbc.gridx = 1;
        btnActualizar = new JButton("Actualizar");
        add(btnActualizar, gbc);

        gbc.gridx = 2;
        btnEliminar = new JButton("Eliminar");
        add(btnEliminar, gbc);

        gbc.gridx = 3;
        btnListar = new JButton("Listar");
        add(btnListar, gbc);

        // Fila 5: Área de texto para listar usuarios
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 4;
        gbc.fill = GridBagConstraints.BOTH;
        txtAreaUsuarios = new JTextArea(5, 30);
        txtAreaUsuarios.setEditable(false);
        add(new JScrollPane(txtAreaUsuarios), gbc);

        // Acciones de botones
        btnAgregar.addActionListener(e -> agregarUsuario());
        btnActualizar.addActionListener(e -> actualizarUsuario());
        btnEliminar.addActionListener(e -> eliminarUsuario());
        btnListar.addActionListener(e -> listarUsuarios());
    }

    private void agregarUsuario() {
        String tipoID = txtTipoID.getText();
        int nroID = Integer.parseInt(txtNroID.getText());
        String nombres = txtNombres.getText();
        String correo = txtCorreo.getText();
        String celular = txtCelular.getText();

        Usuario usuario = new Usuario(tipoID, nroID, nombres, correo, celular);
        if (usuarioDAO.insertarUsuario(usuario)) {
            JOptionPane.showMessageDialog(this, "Usuario agregado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al agregar usuario.");
        }
    }

    private void actualizarUsuario() {
        int nroID = Integer.parseInt(txtNroID.getText());
        String nombres = txtNombres.getText();
        String correo = txtCorreo.getText();
        String celular = txtCelular.getText();

        Usuario usuario = new Usuario("", nroID, nombres, correo, celular);
        if (usuarioDAO.actualizarUsuario(usuario)) {
            JOptionPane.showMessageDialog(this, "Usuario actualizado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar usuario.");
        }
    }

    private void eliminarUsuario() {
        int nroID = Integer.parseInt(txtNroID.getText());
        if (usuarioDAO.eliminarUsuario(nroID)) {
            JOptionPane.showMessageDialog(this, "Usuario eliminado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Error al eliminar usuario.");
        }
    }

    private void listarUsuarios() {
        List<Usuario> usuarios = usuarioDAO.obtenerUsuarios();
        txtAreaUsuarios.setText("");
        for (Usuario u : usuarios) {
            txtAreaUsuarios.append(u.getNombres() + " - " + u.getCorreo() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UsuarioGUI().setVisible(true));
    }
}
