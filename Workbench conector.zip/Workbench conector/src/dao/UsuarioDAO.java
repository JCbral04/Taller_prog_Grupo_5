package dao;

import conexion.ConexionBD;
import modelo.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    
    // Método para INSERTAR usuario
    public boolean insertarUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuario (tipoID, nroID, nombres, correo, celular) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getTipoID());
            stmt.setInt(2, usuario.getNroID());
            stmt.setString(3, usuario.getNombres());
            stmt.setString(4, usuario.getCorreo());
            stmt.setString(5, usuario.getCelular());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para LEER usuarios
    public List<Usuario> obtenerUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM Usuario";
        try (Connection conn = ConexionBD.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Usuario usuario = new Usuario(
                        rs.getString("tipoID"),
                        rs.getInt("nroID"),
                        rs.getString("nombres"),
                        rs.getString("correo"),
                        rs.getString("celular")
                );
                usuarios.add(usuario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    // Método para ACTUALIZAR usuario
    public boolean actualizarUsuario(Usuario usuario) {
        String sql = "UPDATE Usuario SET nombres = ?, correo = ?, celular = ? WHERE nroID = ?";
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNombres());
            stmt.setString(2, usuario.getCorreo());
            stmt.setString(3, usuario.getCelular());
            stmt.setInt(4, usuario.getNroID());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para ELIMINAR usuario
    public boolean eliminarUsuario(int nroID) {
        String sql = "DELETE FROM Usuario WHERE nroID = ?";
        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, nroID);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
