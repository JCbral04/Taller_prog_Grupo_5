package test;

import vista.UsuarioGUI;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UsuarioGUI ventana = new UsuarioGUI();
            ventana.setVisible(true);
        });
    }
}
