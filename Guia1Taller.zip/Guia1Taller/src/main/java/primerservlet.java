import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class primerservlet extends HttpServlet {

    private static final String FILE_PATH = "C:\\Users\\default.LAPTOP-UECHLOAU\\OneDrive - Universidad Manuela Beltrán\\UMB\\7mo Semestre\\Taller\\usuarios.txt"; // Cambia esta ruta por la correcta

    // Método para leer las credenciales y almacenarlas en un HashMap
    private Map<String, String> loadUserCredentials() throws IOException {
        Map<String, String> userCredentials = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(":");
                if (parts.length == 2) {
                    userCredentials.put(parts[0].trim(), parts[1].trim());
                }
            }
        }
        return userCredentials;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Obtener datos del formulario
        String username = request.getParameter("username");
        String password = request.getParameter("passwd");

        // Cargar usuarios desde el archivo
        Map<String, String> userCredentials = loadUserCredentials();
        
        // Validar credenciales
        boolean isAuthenticated = userCredentials.containsKey(username) && userCredentials.get(username).equals(password);

        // Configurar respuesta en HTML
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Autenticación</title>");
            out.println("</head>");
            out.println("<body>");

            if (isAuthenticated) {
                out.println("<h1>Bienvenido, " + username + "!</h1>");
            } else {
                out.println("<h1>Acceso denegado, usuario o contraseña no válidos.</h1>");
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Servlet de autenticación de usuarios desde un archivo de texto";
    }
}
