public class Consumidor implements Runnable {
    private Buffer buffer;

    public Consumidor(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            int numero = buffer.consumir();
            int resultado = numero * 2;
            System.out.println("Consumidor leyó: " + numero + " y lo multiplicó por 2: " + resultado);
            try {
                Thread.sleep(700);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}
