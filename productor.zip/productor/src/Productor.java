import java.util.Random;

public class Productor implements Runnable {
    private Buffer buffer;
    private Random random = new Random();

    public Productor(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            int numero = random.nextInt(100) + 1;
            System.out.println("Productor generó: " + numero);
            buffer.producir(numero);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }
}

