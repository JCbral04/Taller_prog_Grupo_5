public class Buffer {
    private int numero;
    private boolean disponible = false;

    public synchronized void producir(int valor) {
        while (disponible) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        numero = valor;
        disponible = true;
        notify();
    }

    public synchronized int consumir() {
        while (!disponible) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        disponible = false;
        notify();
        return numero;
    }
}
