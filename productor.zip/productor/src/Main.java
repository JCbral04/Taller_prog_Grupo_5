public class Main {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();

        Thread hiloProductor = new Thread(new Productor(buffer));
        Thread hiloConsumidor = new Thread(new Consumidor(buffer));

        hiloProductor.start();
        hiloConsumidor.start();
    }
}
