
package supermercado_corte2;

class Cliente {
    private String nombre;
    private int[] carrito; // precios de los productos

    public Cliente(String nombre, int[] carrito) {
        this.nombre = nombre;
        this.carrito = carrito;
    }

    public String getNombre() {
        return nombre;
    }

    public int[] getCarrito() {
        return carrito;
    }
}

class Cajera extends Thread {
    private Cliente cliente;

    public Cajera(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public void run() {
        System.out.println("Cajera comienza a atender a " + cliente.getNombre());

        int[] productos = cliente.getCarrito();
        int total = 0;

        for (int i = 0; i < productos.length; i++) {
            try {
                Thread.sleep(500); // Simula el tiempo de escanear cada producto
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            total += productos[i];
            System.out.println("Producto " + (i + 1) + " escaneado ($" + productos[i] + ") para " + cliente.getNombre());
        }

        System.out.println("?Total a pagar por " + cliente.getNombre() + ": $" + total);
        System.out.println("Cajera terminó de atender a " + cliente.getNombre() + "\n");
    }
}

public class SuperMercado_Corte2 {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("Laura", new int[]{1000, 2500, 3000});
        Cliente cliente2 = new Cliente("Mateo", new int[]{500, 1500, 800, 2000});
        Cliente cliente3 = new Cliente("Ana", new int[]{4000, 2000});

        // La cajera atiende cliente por cliente (secuencialmente)
        Cajera cajera1 = new Cajera(cliente1);
        cajera1.start();
        try {
            cajera1.join(); // Espera a que termine antes de pasar al siguiente
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Cajera cajera2 = new Cajera(cliente2);
        cajera2.start();
        try {
            cajera2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Cajera cajera3 = new Cajera(cliente3);
        cajera3.start();
        try {
            cajera3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Todas las compras han sido procesadas.");
    }
}
