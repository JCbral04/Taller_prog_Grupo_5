//package ejemplohilos;
//
//public class Ejemplohilos extends Thread{
//    public Ejemplohilos (String str){
//        super(str);
//    }
//    public void run (){
//        for (int i = 0; i < 10; i++){
//        System.out.println("Este ese el thread:" + getName());
//        }
//    }
//    public static void main(String[] args) {
//        Ejemplohilos miThread = new Ejemplohilos("Hilo de prueba");
//        miThread.start();
//                
//    }
//    
//}
