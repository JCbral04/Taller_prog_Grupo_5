//package ejemplohilos;
//public class HiloExtendThread extends Thread {
//    HiloExtendThread(){
//        super("Hilo demo");
//        System.out.println("Hilo hijos: " + this);
//        start();
//    }
//    public void run(){
//       try{
//        for (int i= 5; i>0; i--){
//            System.out.println("Hilo hijo:" + i);
//            Thread.sleep(500);
//        }
//    }catch (InterruptedException e) {
//            System.out.println("Interrupcion del hilo hijo");
//        }
//       System.out.println("Salida del hilo hijo");
//    
//}
//}
//    class ExtendThread{
//        public static void main(String[] args) {
//            new HiloExtendThread();
//            try{
//                for (int i= 5; i>0; i--){
//                    System.out.println("Hilo principal:" + i);
//                    Thread.sleep(1000);
//                }
//            }catch (InterruptedException e) {
//                System.out.println("Interrupcion del hilo principal");
//            }
//            System.out.println("Salida del hilo hijo");
//        }
//    }        
//    
//
