//package callcenter_corte2;
//
//class Persona {
//    private String nombre;
//
//    public Persona(String nombre) {
//        this.nombre = nombre;
//    }
//
//    public String getNombre() {
//        return nombre;
//    }
//}
//
//class Telefono {
//    private String numero;
//
//    public Telefono(String numero) {
//        this.numero = numero;
//    }
//
//    public String getNumero() {
//        return numero;
//    }
//}
//
//class Llamada implements Runnable {
//    private Persona persona;
//    private Telefono telefono;
//
//    public Llamada(Persona persona, Telefono telefono) {
//        this.persona = persona;
//        this.telefono = telefono;
//    }
//
//    @Override
//    public void run() {
//        System.out.println("Atendiendo llamada de " + persona.getNombre() +
//                           " desde el número " + telefono.getNumero() +
//                           " - " + Thread.currentThread().getName());
//
//        try {
//            Thread.sleep(2000); // Simula duración de la llamada
//        } catch (InterruptedException e) {
//            System.out.println("La llamada fue interrumpida.");
//        }
//
//        System.out.println("Llamada finalizada con " + persona.getNombre() +
//                           " - " + Thread.currentThread().getName());
//    }
//}
//
//public class CallCenter_corte2 {
//    public static void main(String[] args) {
//        // Crear personas y teléfonos
//        Persona p1 = new Persona("Laura");
//        Persona p2 = new Persona("Carlos");
//        Persona p3 = new Persona("Mónica");
//
//        Telefono t1 = new Telefono("3210000001");
//        Telefono t2 = new Telefono("3109999992");
//        Telefono t3 = new Telefono("3158888883");
//
//        // Crear llamadas
//        Thread llamada1 = new Thread(new Llamada(p1, t1), "Agente 1");
//        Thread llamada2 = new Thread(new Llamada(p2, t2), "Agente 2");
//        Thread llamada3 = new Thread(new Llamada(p3, t3), "Agente 3");
//
//        // Iniciar llamadas
//        llamada1.start();
//        llamada2.start();
//        llamada3.start();
//    }
//}
//
